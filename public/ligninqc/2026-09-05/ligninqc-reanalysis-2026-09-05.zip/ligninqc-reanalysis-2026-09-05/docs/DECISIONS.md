# Why this release is small

The original LigninQC programme combined literature acquisition, evidence governance, a proposed human-review methodology and planned quantum-chemistry work. A ground-up audit found useful DOI normalization, deduplication, provenance and offline replay components. Those do not themselves answer a chemical question. The older specialized workflow also depended on environment-specific paths and unfinished human-validation tasks.

The public release is therefore a new, narrower product: reproducible secondary analysis of two legally reusable real studies. The historical private packages remain preserved; their provisional findings are not presented here as confirmed errors or a validated benchmark. Completing old administrative counters would not turn them into scientific evidence.

## Concrete usefulness criteria

1. A reader can obtain the entire workflow without credentials or paid access.
2. The package supplies original source context, complete tabular inputs, explicit transformations and data licenses.
3. A clean offline run produces numerical results that agree with a separate source-based implementation.
4. The tool answers a real research decision: how descriptor/subset/state choices affect an association or prediction, and whether a stated comparison agrees with its table.
5. The researcher can reuse the numerical operations on their own explicitly structured table, with useful errors for invalid inputs.
6. Claims remain limited to actual inputs and tests. No claim of human time savings, broad error-detection accuracy or new chemistry is manufactured from software pass counts.

## Baselines and measured outcomes

The scientific baseline is a mean-response prediction trained on the same leave-one-out folds as the descriptor model. For all available DPPH neutral-form observations, linear MAE is 0.322107 RDI versus 0.632784 for the mean baseline. For ABTS with source-informed carboxylate choices, the corresponding values are 0.371589 and 0.532308. These comparisons are internal diagnostics on small related-compound samples, not tests on new chemical series.

A single pooled correlation conceals exclusion and protonation choices. The ten named analysis variants expose that sensitivity. A further ABTS table/prose conflict, discovered during source review, is handled as a separately labelled post-hoc sensitivity, preserving both source values. Numerical tools cannot decide the true experimental value when the source itself is inconsistent.

For source reconciliation, the baseline is reading the same table and prose manually. This release provides inspectable counterexamples and an exact repeatable calculation; it does not have a human comparator study and claims no quantified time advantage. The value is traceability and repeatability, not pretending arithmetic requires a complex framework.

## Release boundaries

The two main source articles and one necessary original structural figure are CC BY 4.0. Additional full texts, private documents, reviewer identities, browser sessions, API keys, cloud accounts and noncommercial-only supplementary archives are not dependencies of the delivered workflow. Raw experimental observations and new DFT outputs are not available here and are not needed for the explicitly bounded published-table analyses.

The code is intentionally standard-library Python. The original larger acquisition/review systems are not silently relabelled as portable or scientifically validated. Optional plot restyling has its own clearly separate development dependencies; the release includes ready-to-use vector/raster figures and all numerical results.

The honest release claim is a complete, reusable published-data reanalysis package with two worked studies and measured computational checks. It is not a complete survey of quantum chemistry in lignin, a proof that BDE alone is sufficient, or an entire novel experimental paper.
