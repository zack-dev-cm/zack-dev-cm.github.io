# Scientific figures

`reference/figures/published-data-reanalysis.{svg,png,pdf}` are publication-quality exports of the actual frozen inputs/results. Panels show the DPPH and ABTS associations and all thermal mass-loss differences. Points are published rounded means; error bars are not plotted. Labels 5, 6 and 16 are source compound identifiers, not a subset exclusion. The fitted line is unconstrained ordinary least squares; a negative fitted RDI is a model limitation, not a physical measurement. Neither internal correlation nor a fitted line establishes a reaction mechanism.

The core CLI recalculates every numerical result without these plotting libraries. The ready-to-read figures are bundled; reading and using them needs no installation. Redrawing their visual style is an optional development task using Python 3.11 or newer for the exact optional package pins below:

```sh
python3 -m venv .figure-venv
.figure-venv/bin/python -m pip install matplotlib==3.10.6 numpy==2.4.6
.figure-venv/bin/python tools/plot_figures.py
```

On Windows use `.figure-venv\Scripts\python` and the corresponding Python launcher. This optional redraw command needs the listed packages (or local wheels); it is not required by `reproduce`, `verify` or any scientific result in the release. The original release figures were rendered with Python 3.11.15, Matplotlib 3.10.6 and NumPy 2.4.6. Vector SVG/PDF exports are supplied so they can be edited without rerunning Python.

Figure attribution: LigninQC contributors (2026), CC BY 4.0; source data Lauberte et al. (2019), DOI 10.3390/molecules24091794, and Kazachenko et al. (2022), DOI 10.3390/polym14153000, both CC BY 4.0. Changes: new plots and descriptive reanalysis of published tables.
