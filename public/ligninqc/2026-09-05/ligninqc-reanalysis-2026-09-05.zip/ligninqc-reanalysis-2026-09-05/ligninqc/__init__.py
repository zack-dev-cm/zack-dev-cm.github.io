"""LigninQC: reproducible, bounded reanalysis of published lignin evidence."""
__version__ = "1.0.0"
